package com.acelera

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

const val K_FILES = 0
const val K_APPS = 1
const val K_CACHE = 2

class Item(val label: String, val size: Long, val file: File? = null, val pkg: String? = null)

class Finding(
    val emoji: String, val title: String, val desc: String,
    val kind: Int, val items: List<Item>, val preChecked: Boolean
) {
    val total: Long get() = items.sumOf { it.size }
}

class Threat(val label: String, val pkg: String, val score: Int, val reasons: List<String>)

class MainActivity : Activity() {
    private val indigo = Color.parseColor("#5B5BD6")
    private val ink = Color.parseColor("#1F1B2E")
    private lateinit var scanScroll: ScrollView
    private lateinit var resScroll: ScrollView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var storageTxt: TextView
    private lateinit var bar: ProgressBar
    private lateinit var scanBtn: TextView
    private lateinit var allBtn: TextView
    private lateinit var tab1: TextView
    private lateinit var tab2: TextView
    private lateinit var ind1: View
    private lateinit var ind2: View
    private lateinit var tab3: TextView
    private lateinit var ind3: View
    private lateinit var secScroll: ScrollView
    private lateinit var secList: LinearLayout
    private lateinit var secStatus: TextView
    private lateinit var secScanBtn: TextView
    private lateinit var excBtn: TextView
    private var secRescan = false
    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.mipicks", "com.heytap.market", "com.amazon.venezia"
    )
    private val opt = booleanArrayOf(true, true, true, true)
    private var lastRes: List<Finding> = emptyList()
    private val uninstallQueue = ArrayDeque<String>()
    private var rescan = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#5B5FD6")
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (uninstallQueue.isNotEmpty()) nextUninstall()
        else if (rescan) { rescan = false; analyze() }
        else if (secRescan) { secRescan = false; scanThreats() }
    }

    private fun nextUninstall() {
        if (uninstallQueue.isEmpty()) return
        val pkg = uninstallQueue.removeFirst()
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun cardParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(dp(16), dp(6), dp(16), dp(6)) }

    private fun pill(text: String, filled: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = 17f; gravity = Gravity.CENTER
        setTypeface(null, Typeface.BOLD); isClickable = true
        if (filled) {
            setTextColor(Color.WHITE); background = shape(indigo, 28)
        } else {
            setTextColor(Color.parseColor("#6B6B8A")); background = shape(Color.TRANSPARENT, 28, Color.parseColor("#D9D6EE"))
        }
    }

    private fun styleChip(c: TextView, on: Boolean) {
        if (on) {
            c.background = shape(Color.parseColor("#F6D5E8"), 14)
            c.setTextColor(ink)
        } else {
            c.background = shape(Color.TRANSPARENT, 14, Color.parseColor("#6B7280"))
            c.setTextColor(Color.parseColor("#374151"))
        }
    }

    private fun chip(t: String) = TextView(this).apply {
        text = t; textSize = 14f; gravity = Gravity.CENTER; isClickable = true
    }

    private fun row(idx: Int, emoji: String, bg: String, name: String): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        r.addView(TextView(this).apply {
            text = emoji; textSize = 22f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(bg)) }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        r.addView(TextView(this).apply {
            text = name; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(ink)
            setPadding(dp(14), 0, dp(4), 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val on = chip("Incluir")
        val off = chip("Omitir")
        fun refresh() { styleChip(on, opt[idx]); styleChip(off, !opt[idx]) }
        on.setOnClickListener { opt[idx] = true; refresh() }
        off.setOnClickListener { opt[idx] = false; refresh() }
        refresh()
        r.addView(on, LinearLayout.LayoutParams(dp(84), dp(44)))
        r.addView(off, LinearLayout.LayoutParams(dp(84), dp(44)).apply { leftMargin = dp(8) })
        return r
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F5F3FF"))
        }
        // Cabecera
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#5B5FD6"), Color.parseColor("#8B54E8"), Color.parseColor("#FF6FA5"))
            )
        }
        val logoBox = FrameLayout(this).apply { background = shape(Color.WHITE, 22) }
        logoBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo); setPadding(dp(6), dp(6), dp(6), dp(6))
        }, FrameLayout.LayoutParams(dp(76), dp(76)))
        header.addView(logoBox, LinearLayout.LayoutParams(dp(76), dp(76)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        col.addView(TextView(this).apply {
            text = "Cleanmovil"; textSize = 28f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Encuentra lo que ralentiza tu teléfono y déjalo veloz"
            textSize = 15f; setTextColor(Color.WHITE)
        })
        header.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        // Pestañas
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), dp(4), dp(16), 0)
        }
        fun tabCol(label: String, onClick: () -> Unit): Triple<LinearLayout, TextView, View> {
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val t = TextView(this).apply {
                text = label; textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { onClick() }
            }
            val i = View(this)
            c.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            c.addView(i, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
            return Triple(c, t, i)
        }
        val t1 = tabCol("Analizar") { selectTab(0) }
        val t2 = tabCol("Resultados") { selectTab(1) }
        val t3 = tabCol("Seguridad") { selectTab(2) }
        tab1 = t1.second; ind1 = t1.third; tab2 = t2.second; ind2 = t2.third
        tab3 = t3.second; ind3 = t3.third
        tabs.addView(t1.first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(t2.first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(t3.first, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)

        // Panel Analizar
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(24)) }
        panel.addView(TextView(this).apply {
            text = "¿Qué quieres analizar?"; textSize = 22f; setTypeface(null, Typeface.BOLD); setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })
        panel.addView(row(0, "🗑️", "#FDE2EF", "Temporales"))
        panel.addView(row(1, "📦", "#E4DDFB", "Instaladores"))
        panel.addView(row(2, "🐘", "#FCE7D3", "Grandes"))
        panel.addView(row(3, "📱", "#D6EEFB", "Apps"))
        panel.addView(TextView(this).apply {
            text = "Temporales: basura, miniaturas y carpetas vacías. Grandes: archivos de más de 100 MB. Apps: sin uso y con mucha caché. Nada se borra sin que tú confirmes."
            textSize = 14f; setTextColor(Color.parseColor("#6B7280")); setPadding(0, dp(10), 0, dp(10))
        })
        storageTxt = TextView(this).apply { textSize = 14f; setTextColor(ink); setTypeface(null, Typeface.BOLD) }
        panel.addView(storageTxt)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(indigo)
        }
        panel.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)).apply { topMargin = dp(6); bottomMargin = dp(16) })
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scanBtn = pill("🔍 Analizar", true).apply { setOnClickListener { analyze() } }
        allBtn = pill("🚀 Resolver todo", false).apply { isEnabled = false; alpha = 0.5f }
        btns.addView(scanBtn, LinearLayout.LayoutParams(0, dp(56), 1f))
        btns.addView(allBtn, LinearLayout.LayoutParams(0, dp(56), 1f).apply { leftMargin = dp(12) })
        panel.addView(btns)
        status = TextView(this).apply {
            text = "Elige qué analizar y toca Analizar."
            textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#8A8AA5"))
            setPadding(dp(8), dp(28), dp(8), 0)
        }
        panel.addView(status)
        scanScroll = ScrollView(this).apply { addView(panel) }
        root.addView(scanScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Panel Resultados
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(24)) }
        resScroll = ScrollView(this).apply { addView(list); visibility = View.GONE }
        root.addView(resScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Panel Seguridad
        val sec = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(16), 0, dp(24)) }
        val secTop = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), dp(8)) }
        secTop.addView(TextView(this).apply {
            text = "Seguridad"; textSize = 22f; setTypeface(null, Typeface.BOLD); setTextColor(ink)
            setPadding(0, 0, 0, dp(6))
        })
        secTop.addView(TextView(this).apply {
            text = "Busca apps sospechosas, malware o programas espía según sus permisos y cómo se instalaron. No es un antivirus con base de virus: puede marcar apps legítimas, por eso puedes crear excepciones."
            textSize = 14f; setTextColor(Color.parseColor("#6B7280")); setPadding(0, 0, 0, dp(14))
        })
        val secBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        secScanBtn = pill("🛡️ Buscar amenazas", true).apply { textSize = 15f; setOnClickListener { scanThreats() } }
        excBtn = pill("Excepciones (${exceptions().size})", false).apply { textSize = 15f; setOnClickListener { showExceptions() } }
        secBtns.addView(secScanBtn, LinearLayout.LayoutParams(0, dp(56), 1f))
        secBtns.addView(excBtn, LinearLayout.LayoutParams(0, dp(56), 1f).apply { leftMargin = dp(12) })
        secTop.addView(secBtns)
        secStatus = TextView(this).apply {
            text = "Toca Buscar amenazas para revisar tus apps."
            textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#8A8AA5"))
            setPadding(dp(8), dp(22), dp(8), dp(8))
        }
        secTop.addView(secStatus)
        secList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sec.addView(secTop)
        sec.addView(secList)
        secScroll = ScrollView(this).apply { addView(sec); visibility = View.GONE }
        root.addView(secScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        selectTab(0)
        showStorage()
    }

    private fun selectTab(i: Int) {
        scanScroll.visibility = if (i == 0) View.VISIBLE else View.GONE
        resScroll.visibility = if (i == 1) View.VISIBLE else View.GONE
        secScroll.visibility = if (i == 2) View.VISIBLE else View.GONE
        val off = Color.parseColor("#D1D5DB")
        tab1.setTextColor(indigo); tab2.setTextColor(indigo); tab3.setTextColor(indigo)
        ind1.setBackgroundColor(if (i == 0) indigo else off)
        ind2.setBackgroundColor(if (i == 1) indigo else off)
        ind3.setBackgroundColor(if (i == 2) indigo else off)
    }

    private fun showStorage() {
        val st = StatFs(Environment.getExternalStorageDirectory().path)
        val total = st.totalBytes
        val used = total - st.availableBytes
        val pct = if (total > 0) (used * 100 / total).toInt() else 0
        storageTxt.text = "Almacenamiento: ${fmt(used)} usados de ${fmt(total)} ($pct%)"
        bar.progress = pct
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun analyze() {
        if (opt.none { it }) {
            Toast.makeText(this, "Elige al menos una opción para analizar", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Activa «Acceso a todos los archivos» para Cleanmovil y vuelve a tocar Analizar", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (opt[3] && !hasUsage()) {
            Toast.makeText(this, "Activa el «Acceso de uso» para Cleanmovil y vuelve a tocar Analizar", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        selectTab(0)
        scanBtn.isEnabled = false; scanBtn.alpha = 0.6f
        status.text = "Analizando… esto puede tardar un momento"
        showStorage()
        val flags = opt.copyOf()
        Thread {
            val res = try { scan(flags) } catch (e: Exception) { emptyList() }
            runOnUiThread { show(res) }
        }.start()
    }

    private fun scan(o: BooleanArray): List<Finding> {
        val root = Environment.getExternalStorageDirectory()
        val androidDir = File(root, "Android")
        val temp = ArrayList<Item>()
        val thumbs = ArrayList<Item>()
        val apks = ArrayList<Item>()
        val big = ArrayList<Item>()
        val empty = ArrayList<Item>()
        val prefix = root.absolutePath

        fun walk(d: File) {
            val fs = d.listFiles() ?: return
            if (fs.isEmpty() && d != root) {
                empty.add(Item(d.absolutePath.removePrefix(prefix), 0, d)); return
            }
            for (f in fs) {
                if (f.isDirectory) {
                    if (f == androidDir) continue
                    if (f.name == ".thumbnails") {
                        f.walkTopDown().filter { it.isFile }
                            .forEach { thumbs.add(Item(it.name, it.length(), it)) }
                        continue
                    }
                    walk(f)
                } else {
                    val n = f.name.lowercase()
                    val s = f.length()
                    val item = Item(f.absolutePath.removePrefix(prefix), s, f)
                    when {
                        n.startsWith(".thumbdata") -> thumbs.add(item)
                        n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".cache") ||
                            n.endsWith(".crdownload") || n.endsWith(".part") ||
                            n.endsWith(".log") || n.endsWith(".bak") || n.endsWith(".old") -> temp.add(item)
                        n.endsWith(".apk") -> apks.add(item)
                        s > 100L * 1024 * 1024 -> big.add(item)
                    }
                }
            }
        }
        if (o[0] || o[1] || o[2]) walk(root)

        val unused = ArrayList<Item>()
        val cache = ArrayList<Item>()
        if (o[3]) {
            val now = System.currentTimeMillis()
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val usage = usm.queryAndAggregateUsageStats(now - 365L * 86400000, now)
            val ssm = getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            for (ai in packageManager.getInstalledApplications(0)) {
                if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || ai.packageName == packageName) continue
                val label = packageManager.getApplicationLabel(ai).toString()
                var size = 0L
                var cacheB = 0L
                try {
                    val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, Process.myUserHandle())
                    size = s.appBytes + s.dataBytes
                    cacheB = s.cacheBytes
                } catch (e: Exception) { }
                val last = usage[ai.packageName]?.lastTimeUsed ?: 0L
                val days = if (last == 0L) 365L else (now - last) / 86400000
                if (days >= 30) {
                    val whenTxt = if (last == 0L) "sin uso en el último año" else "sin abrir hace $days días"
                    unused.add(Item("$label · $whenTxt", size, pkg = ai.packageName))
                }
                if (cacheB > 50L * 1024 * 1024) cache.add(Item(label, cacheB, pkg = ai.packageName))
            }
        }

        val out = ArrayList<Finding>()
        if (cache.isNotEmpty()) out.add(Finding("🧹", "Apps con mucha caché",
            "Android solo permite borrar la caché de otras apps desde sus Ajustes. Toca una para abrirla.",
            K_CACHE, cache.sortedByDescending { it.size }, false))
        if (unused.isNotEmpty()) out.add(Finding("😴", "Apps sin usar (30+ días)",
            "Apps que casi no abres y ocupan espacio. Elige cuáles desinstalar.",
            K_APPS, unused.sortedByDescending { it.size }, false))
        if (o[0] && temp.isNotEmpty()) out.add(Finding("🗑️", "Archivos temporales",
            "Descargas incompletas, registros y copias viejas que ya no sirven.",
            K_FILES, temp.sortedByDescending { it.size }, true))
        if (o[0] && thumbs.isNotEmpty()) out.add(Finding("🖼️", "Miniaturas antiguas",
            "Imágenes en caché que la galería ya no necesita.",
            K_FILES, thumbs.sortedByDescending { it.size }, true))
        if (o[0] && empty.isNotEmpty()) out.add(Finding("📁", "Carpetas vacías",
            "Carpetas sin nada dentro que desordenan el almacenamiento.",
            K_FILES, empty, true))
        if (o[1] && apks.isNotEmpty()) out.add(Finding("📦", "Instaladores APK",
            "Instaladores que ya usaste y siguen ocupando espacio.",
            K_FILES, apks.sortedByDescending { it.size }, false))
        if (o[2] && big.isNotEmpty()) out.add(Finding("🐘", "Archivos muy grandes",
            "Archivos de más de 100 MB. Revisa cuáles ya no necesitas.",
            K_FILES, big.sortedByDescending { it.size }, false))
        return out
    }

    private fun show(res: List<Finding>) {
        lastRes = res
        scanBtn.isEnabled = true; scanBtn.alpha = 1f
        list.removeAllViews()
        showStorage()
        val safe = res.filter { it.kind == K_FILES && it.preChecked }
        val safeItems = safe.flatMap { it.items }
        allBtn.isEnabled = safeItems.isNotEmpty()
        allBtn.alpha = if (safeItems.isNotEmpty()) 1f else 0.5f
        allBtn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("¿Dejar el teléfono más rápido?")
                .setMessage("Se eliminarán ${safeItems.size} elementos (temporales, miniaturas y carpetas vacías) y se liberarán ${fmt(safeItems.sumOf { it.size })}.")
                .setPositiveButton("Sí, limpiar") { _, _ -> deleteFiles(safeItems) }
                .setNegativeButton("No", null).show()
        }
        if (res.isEmpty()) {
            status.text = "¡Tu teléfono está limpio! 🎉"
            return
        }
        status.text = "Listo. Revisa la pestaña Resultados."
        list.addView(TextView(this).apply {
            text = "Encontré ${res.size} cosas que lo ralentizan"
            textSize = 20f; setTypeface(null, Typeface.BOLD); setTextColor(ink)
            setPadding(dp(18), dp(6), dp(18), dp(6))
        })
        res.forEach { list.addView(card(it), cardParams()) }
        selectTab(1)
    }

    private fun card(f: Finding): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.WHITE, 20, Color.parseColor("#E5E0F7"))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = f.emoji; textSize = 20f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#EFEAFD")) }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(TextView(this).apply {
            text = f.title; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(ink)
            setPadding(dp(12), 0, 0, 0)
        })
        c.addView(head)
        c.addView(TextView(this).apply {
            text = f.desc; textSize = 14f; setTextColor(Color.parseColor("#4B5563"))
            setPadding(0, dp(8), 0, dp(6))
        })
        c.addView(TextView(this).apply {
            text = "${f.items.size} elementos · ${fmt(f.total)}"; textSize = 15f
            setTypeface(null, Typeface.BOLD); setTextColor(indigo)
            setPadding(0, 0, 0, dp(10))
        })
        c.addView(pill(if (f.kind == K_CACHE) "Ver apps" else "Resolver", true).apply {
            setOnClickListener { resolve(f) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        return c
    }

    // ---------- Seguridad ----------
    private fun prefs() = getSharedPreferences("cleanmovil", Context.MODE_PRIVATE)

    private fun exceptions(): MutableSet<String> =
        HashSet(prefs().getStringSet("exc", emptySet()) ?: emptySet())

    private fun saveExceptions(set: Set<String>) {
        prefs().edit().putStringSet("exc", HashSet(set)).apply()
        excBtn.text = "Excepciones (${set.size})"
    }

    private fun scanThreats() {
        selectTab(2)
        secScanBtn.isEnabled = false; secScanBtn.alpha = 0.6f
        secStatus.text = "Revisando apps instaladas…"
        secList.removeAllViews()
        val exc = exceptions()
        Thread {
            val res = try { findThreats(exc) } catch (e: Exception) { emptyList() }
            runOnUiThread { showThreats(res) }
        }.start()
    }

    private fun findThreats(exc: Set<String>): List<Threat> {
        val pm = packageManager
        val enabledAcc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admins = dpm.activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        val spyWords = listOf("spy", "stealth", "keylog", "flexispy", "mspy", "hoverwatch", "spyic", "spyera", "truthspy", "cocospy", "snoop")
        val smsPerms = setOf("android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS")
        val dataPerms = listOf(
            "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
            "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_CONTACTS"
        )
        val out = ArrayList<Threat>()
        for (ai in pm.getInstalledApplications(0)) {
            val pkg = ai.packageName
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || pkg == packageName || pkg in exc) continue
            val pi = try { pm.getPackageInfo(pkg, flags) } catch (e: Exception) { continue }
            val label = pm.getApplicationLabel(ai).toString()
            val perms = pi.requestedPermissions?.toSet() ?: emptySet()
            val reasons = ArrayList<String>()
            var score = 0
            val installer = try { pm.getInstallSourceInfo(pkg).installingPackageName } catch (e: Exception) { null }
            val trusted = installer != null && installer in trustedStores
            if (!trusted) { score += 2; reasons.add("Instalada fuera de una tienda oficial") }
            if (pi.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true) {
                score += 3; reasons.add("Tiene servicio de accesibilidad: puede leer la pantalla y tocar por ti")
                if (enabledAcc.contains(pkg)) { score += 1; reasons.add("Ese servicio está activo ahora") }
            }
            if (pi.services?.any { it.permission == "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" } == true) {
                score += 2; reasons.add("Puede leer tus notificaciones (mensajes y códigos)")
            }
            if (pkg in admins) { score += 3; reasons.add("Es administrador del dispositivo: dificulta desinstalarla") }
            if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) { score += 2; reasons.add("Puede dibujar encima de otras apps") }
            if (perms.any { it in smsPerms }) { score += 2; reasons.add("Puede leer o enviar SMS") }
            if ("android.permission.READ_CALL_LOG" in perms) { score += 1; reasons.add("Puede leer tu registro de llamadas") }
            if (dataPerms.all { it in perms }) { score += 1; reasons.add("Pide micrófono, cámara, ubicación y contactos a la vez") }
            if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms && !trusted) { score += 1; reasons.add("Puede instalar otras apps") }
            if (pm.getLaunchIntentForPackage(pkg) == null && !trusted) { score += 2; reasons.add("No tiene icono: se oculta del menú") }
            val lower = "$label $pkg".lowercase()
            if (spyWords.any { lower.contains(it) }) { score += 4; reasons.add("Su nombre es típico de programas espía") }
            if (trusted) score = maxOf(0, score - 2)
            if (score >= 4) out.add(Threat(label, pkg, score, reasons))
        }
        return out.sortedByDescending { it.score }
    }

    private fun showThreats(res: List<Threat>) {
        secScanBtn.isEnabled = true; secScanBtn.alpha = 1f
        secList.removeAllViews()
        if (res.isEmpty()) {
            secStatus.text = "✅ No encontré apps sospechosas"
            return
        }
        res.forEach { secList.addView(threatCard(it), cardParams()) }
        updateSecStatus()
    }

    private fun updateSecStatus() {
        val n = secList.childCount
        secStatus.text = if (n == 0) "✅ Listo, no quedan apps por revisar" else "⚠️ $n app(s) sospechosa(s). Elige qué hacer con cada una."
    }

    private fun threatCard(t: Threat): View {
        val high = t.score >= 6
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.WHITE, 20, Color.parseColor(if (high) "#FCA5A5" else "#FCD34D"))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(TextView(this).apply {
            text = "${if (high) "🚨" else "⚠️"} ${t.label}"; textSize = 18f
            setTypeface(null, Typeface.BOLD); setTextColor(ink)
        })
        c.addView(TextView(this).apply {
            text = t.pkg; textSize = 12f; setTextColor(Color.parseColor("#9CA3AF"))
        })
        c.addView(TextView(this).apply {
            text = if (high) "Riesgo ALTO" else "Riesgo MEDIO"; textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor(if (high) "#DC2626" else "#D97706"))
            setPadding(0, dp(6), 0, dp(4))
        })
        c.addView(TextView(this).apply {
            text = t.reasons.joinToString("\n") { "• $it" }
            textSize = 14f; setTextColor(Color.parseColor("#4B5563"))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        val del = pill("Eliminar", true).apply {
            textSize = 14f; background = shape(Color.parseColor("#DC2626"), 22)
            setOnClickListener { removeThreat(t) }
        }
        val exc = pill("Excepción", false).apply {
            textSize = 14f
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("¿Crear excepción para ${t.label}?")
                    .setMessage("Esta app no volverá a aparecer en el análisis de seguridad. Puedes quitar la excepción en el botón Excepciones.")
                    .setPositiveButton("Sí, crear excepción") { _, _ ->
                        val set = exceptions(); set.add(t.pkg); saveExceptions(set)
                        secList.removeView(c); updateSecStatus()
                    }
                    .setNegativeButton("Cancelar", null).show()
            }
        }
        val ign = pill("Ignorar", false).apply {
            textSize = 14f
            setOnClickListener { secList.removeView(c); updateSecStatus() }
        }
        row.addView(del, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(exc, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        row.addView(ign, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        c.addView(row)
        return c
    }

    private fun removeThreat(t: Threat) {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.activeAdmins?.any { it.packageName == t.pkg } == true) {
            AlertDialog.Builder(this)
                .setTitle("${t.label} es administradora del dispositivo")
                .setMessage("Android no deja desinstalarla hasta que le quites ese permiso. Ve a Ajustes > Seguridad > Administradores del dispositivo, desactívala y vuelve a tocar Eliminar.")
                .setPositiveButton("Abrir Ajustes") { _, _ -> startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
                .setNegativeButton("Cancelar", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("¿Eliminar ${t.label}?")
            .setMessage("Se abrirá la pantalla de Android para confirmar la desinstalación.")
            .setPositiveButton("Eliminar") { _, _ ->
                secRescan = true
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${t.pkg}")))
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun showExceptions() {
        val exc = exceptions().toList()
        if (exc.isEmpty()) {
            Toast.makeText(this, "No tienes excepciones", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = exc.map { pkg ->
            try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() + "\n" + pkg
            } catch (e: Exception) { pkg }
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Excepciones (toca una para quitarla)")
            .setItems(labels) { _, i ->
                val set = exceptions(); set.remove(exc[i]); saveExceptions(set)
                Toast.makeText(this, "Excepción quitada. Vuelve a buscar amenazas.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cerrar", null).show()
    }

    private fun resolve(f: Finding) {
        val labels = f.items.map { "${it.label}\n${fmt(it.size)}" }.toTypedArray()
        if (f.kind == K_CACHE) {
            AlertDialog.Builder(this).setTitle(f.title)
                .setItems(labels) { _, i ->
                    Toast.makeText(this, "Entra a Almacenamiento y toca «Borrar caché»", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${f.items[i].pkg}")))
                }
                .setNegativeButton("Cerrar", null).show()
            return
        }
        if (f.kind == K_FILES && f.items.size > 200) {
            AlertDialog.Builder(this).setTitle("¿Resolver: ${f.title}?")
                .setMessage("Se eliminarán ${f.items.size} elementos y se liberarán ${fmt(f.total)}.")
                .setPositiveButton("Sí, resolver") { _, _ -> deleteFiles(f.items) }
                .setNegativeButton("No", null).show()
            return
        }
        val checked = BooleanArray(f.items.size) { f.preChecked }
        AlertDialog.Builder(this).setTitle("¿Resolver: ${f.title}?")
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(if (f.kind == K_APPS) "Desinstalar" else "Eliminar") { _, _ ->
                val sel = f.items.filterIndexed { i, _ -> checked[i] }
                if (sel.isEmpty()) {
                    Toast.makeText(this, "No elegiste nada", Toast.LENGTH_SHORT).show()
                } else if (f.kind == K_APPS) {
                    sel.forEach { uninstallQueue.addLast(it.pkg!!) }
                    rescan = true
                    nextUninstall()
                } else deleteFiles(sel)
            }
            .setNegativeButton("No", null).show()
    }

    private fun deleteFiles(items: List<Item>) {
        status.text = "Limpiando…"
        Thread {
            var freed = 0L
            var n = 0
            items.forEach { if (it.file?.delete() == true) { freed += it.size; n++ } }
            runOnUiThread {
                Toast.makeText(this, "Listo: $n elementos eliminados, ${fmt(freed)} liberados", Toast.LENGTH_LONG).show()
                analyze()
            }
        }.start()
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> String.format("%.1f GB", b / 1073741824.0)
        b >= 1L shl 20 -> String.format("%.0f MB", b / 1048576.0)
        else -> "${b / 1024} KB"
    }
}
