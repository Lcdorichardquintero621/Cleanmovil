# Cleanmovil

App Android que acelera tu teléfono y busca amenazas.

- **Analizar:** temporales, miniaturas, carpetas vacías, instaladores APK, archivos grandes, apps sin uso y apps con mucha caché.
- **Resultados:** informe de cada hallazgo; te pregunta antes de eliminar o desinstalar.
- **Seguridad:** detecta apps sospechosas (por permisos y origen de instalación). Puedes eliminar, crear una excepción o ignorar.

## Compilar el APK
Cada `push` ejecuta GitHub Actions (`.github/workflows/build.yml`).
El APK queda en **Actions > último workflow > Artifacts > Cleanmovil-APK**.

## Estructura
- `app/src/main/java/com/acelera/MainActivity.kt`: toda la lógica y la interfaz.
- `app/src/main/res/`: icono y logo.
